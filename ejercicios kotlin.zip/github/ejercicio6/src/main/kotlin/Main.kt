    fun factorial()
    {
        println("Ingrese un numero:")
        var n = readLine()!!.toInt()

        for (i in n-1 downTo 1)
        {
            n *= i
        }
        println("Factorial: $n")
    }

    fun main(args: Array<String>) {
        factorial()
    }