fun main(args: Array<String>) {

        val strings = listOf("cancha","ugo","armnistisio","dedo","ballesta","zapato")
        val sortedStrings = strings.sortedBy { it.length }
        println(sortedStrings)

}