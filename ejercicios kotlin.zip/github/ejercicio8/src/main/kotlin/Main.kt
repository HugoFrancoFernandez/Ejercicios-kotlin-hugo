fun main(args: Array<String>) {
    var cadena: String
    var vocales = 0
    var a_vocal=0
    var e_vocal=0
    var i_vocal=0
    var o_vocal=0
    var u_vocal=0
    println("Teclee una cadena:")
    cadena = readLine().toString()
    cadena = cadena.toLowerCase()
    for (i in 0..cadena.length - 1) {
        val ch = cadena[i]
        if (ch == 'a' || ch == 'e' || ch == 'i'
            || ch == 'o' || ch == 'u'
        ) {
            ++vocales
        }
        if (ch=='a') {
            ++a_vocal
        }
        if (ch=='e')
        {
            ++e_vocal
        }
        if (ch=='i')
        {
            ++i_vocal
        }
        if (ch=='o')
        {
            ++o_vocal
        }
        if (ch=='u')
        {
            ++u_vocal
        }
    }

    println("Vocales totales: $vocales")
    println("Vocales a: $a_vocal")
    println("Vocales e: $e_vocal")
    println("Vocales i: $i_vocal")
    println("Vocales o: $o_vocal")
    println("Vocales u: $u_vocal")

}