fun main(args: Array<String>) {

    //1. Hacer un programa que llene un arreglo de 10 enteros y deberá elevar al cuadrado cada
            //elemento del arreglo.

    val vector: Array<Int> = arrayOf(0,2,5,3,1,4,6,9,8,7)

    val square = pow (num = vector[0])
    println("P0: $square")
    val square1 = pow (num = vector[1])
    println("P1: $square1")
    val square2 = pow (num = vector[2])
    println("P2: $square2")
    val square3 = pow (num = vector[3])
    println("P3: $square3")
    val square4 = pow (num = vector[4])
    println("P4: $square4")
    val square5 = pow (num = vector[5])
    println("P5: $square5")
    val square6 = pow (num = vector[6])
    println("P6: $square6")
    val square7 = pow (num = vector[7])
    println("P7: $square7")
    val square8 = pow (num = vector[8])
    println("P8: $square8")
    val square9 = pow (num = vector[9])
    println("P9: $square9")
}
fun pow(num: Int, pow: Int = 2):Int{
    var resultado: Int = 1
    for(i in 1..pow){
        resultado = resultado * num
    }
    return resultado
}